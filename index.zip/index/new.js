function addMessage(text, sender) {

    const messageList = document.getElementById('message-list');

    // Main Row
    const rowDiv = document.createElement('div');
    rowDiv.className = "chat-row";

    // Avatar Image
    const avatar = document.createElement('img');
    avatar.className = "chat-avatar";

    // Random placeholder images (Replace later)
    const userImg = "https://i.pravatar.cc/100?img=12";
    const botImg = "https://i.pravatar.cc/100?img=33";

    avatar.src = sender === "user" ? userImg : botImg;
    avatar.alt = sender === "user" ? "User" : "Bot";

    // Content Wrapper
    const contentDiv = document.createElement('div');
    contentDiv.className = "chat-content";

    // Bubble
    const bubbleDiv = document.createElement('div');
    bubbleDiv.className = `chat-bubble ${sender === 'user' ? 'user-msg' : 'ai-msg'}`;
    bubbleDiv.innerText = text;

    contentDiv.appendChild(bubbleDiv);

    // ✅ Only for AI message (References + Icons)
    if (sender === "ai") {

        const footerDiv = document.createElement("div");
        footerDiv.className = "ai-footer";

        // References
        const refDiv = document.createElement("div");
        refDiv.className = "ai-references";

        refDiv.innerHTML = `
            <a href="https://example.com" target="_blank"><i class="bi bi-link-45deg me-1"></i>Reference 1</a>
            <a href="https://example.com" target="_blank"><i class="bi bi-link-45deg me-1"></i>Reference 2</a>
            <a href="https://example.com" target="_blank"><i class="bi bi-link-45deg me-1"></i>Reference 3</a>
        `;

        // Actions Icons
        const actionDiv = document.createElement("div");
        actionDiv.className = "ai-actions";

        actionDiv.innerHTML = `
            <i class="bi bi-clipboard" title="Copy"></i>
            <i class="bi bi-hand-thumbs-up" title="Like"></i>
            <i class="bi bi-hand-thumbs-down" title="Dislike"></i>
        `;

        // Copy functionality
        actionDiv.querySelector(".bi-clipboard").addEventListener("click", () => {
            navigator.clipboard.writeText(text);
        });

        footerDiv.appendChild(refDiv);
        footerDiv.appendChild(actionDiv);

        contentDiv.appendChild(footerDiv);
    }

    // Append avatar + content into row
    rowDiv.appendChild(avatar);
    rowDiv.appendChild(contentDiv);

    // Add row into message list
    messageList.appendChild(rowDiv);

    window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
}
