---
title: 4 square
categories:
  - Shapes
tags:
  - number
  - numeral
---
