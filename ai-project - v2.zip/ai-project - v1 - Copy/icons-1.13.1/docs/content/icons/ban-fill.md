---
title: Ban fill
categories:
  - Real world
tags:
  - no
  - "not allowed"
added: 1.11.0
---
