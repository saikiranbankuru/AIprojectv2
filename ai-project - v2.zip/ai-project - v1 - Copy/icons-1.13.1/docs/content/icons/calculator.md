---
title: Calculator
categories:
  - Devices
tags:
  - calculator
  - math
---
